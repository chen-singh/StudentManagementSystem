import java.util.Scanner;

public class Student {
    public String id;
    public String name;
    public String departmnt;
    public double cgpa;

    public String getName() {
        return name;
    }

    public String getDepartmnt() {
        return departmnt;
    }

    public double getCgpa() {
        return cgpa;
    }

    public String getId() {
        return id;
    }

    public Student(String id, String name,String departmnt,double cgpa){
        this.id=id;
        this.name=name;
        this.departmnt=departmnt;
        this.cgpa=cgpa;
    }



    @Override
    public String toString(){
     return "Id:  "+id+ "Name:  "+name+"depart:    "+departmnt+"CGPA :     "+cgpa;
    }
}
