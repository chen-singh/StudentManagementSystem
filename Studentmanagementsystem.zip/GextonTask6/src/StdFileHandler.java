import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StdFileHandler {
     Scanner sc;
     List<Student> student;

     public StdFileHandler(){
         sc=new Scanner(System.in);
         student=new ArrayList<>();


     }

     public void savetoFile() {
         try (PrintWriter writer = new PrintWriter(new FileWriter("student.txt"))) {
             for (Student student : student) {
                 writer.println(student.getId() + "," + student.getName() + "," + student.getDepartmnt()+" , "+ student.getCgpa());
             }
         } catch (IOException e) {
             System.out.println("Error saving students: " + e.getMessage());
         }
     }


    public void addstudent() throws IOException {
        System.out.println("Enter Your Id : ");
        String id=sc.next();
        System.out.println("Enter Name : ");
        String name=sc.next();
        System.out.println("Enter department : ");
        String depart=sc.next();
        System.out.println("enter your cgpa");
        double cpga=sc.nextDouble();
        sc.nextLine();
        student.add(new Student(id,name,depart,cpga));
        savetoFile();
        System.out.println("Student added successfully");

     }
     public void Update(){
         System.out.println("Enter Your Id: ");
         String id=sc.next();
         for (Student student1:student){
             if (student1.getId().equals(id)){
                 System.out.println("Enter  new name : ");
                 String name=sc.next();
                 System.out.println("Enter department");
                 String depart=sc.next();
                 System.out.println("Enter your gpa");
                 double gpa=sc.nextDouble();
                 sc.nextLine();
                 student.remove(student1);
                 student.add(new Student(id,name,depart,gpa));
                 savetoFile();
                 System.out.println("Student updated successfully");

             }else {
                 System.out.println("student not found");
             }
         }


     }
     public void Search() throws FileNotFoundException {
         System.out.println("Enter Id : ");
         String id=sc.next();
         for (Student student1:student){
             if (student1.getId().equals(id)) {

                 System.out.println(student1.toString());


             }
             }
         }
    public void Deletestud() throws  Exception{
        System.out.println("Enter Id to delete");
        String id=sc.next();
        for (Student student1:student){
            if (student1.getId().equals(id)){
                student.remove(student1);
                savetoFile();
                System.out.println("Student deleted successfully");
            }

        }

    }
     public void viewStudents() throws FileNotFoundException {
         File myfile=new File("student.txt");

         Scanner scanner=new Scanner(System.in);
         scanner=new Scanner(myfile);
         while (scanner.hasNextLine()){
             String line= scanner.nextLine();
             System.out.println(line);
         }
         scanner.close();
     }


}
