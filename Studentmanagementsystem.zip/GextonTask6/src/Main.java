
import java.util.Scanner;
public class Main {
    public static void main(String[] args) throws Exception {
      StdFileHandler std=new StdFileHandler();

        Scanner scanner = new Scanner(System.in);
        int choice;
        System.out.println("Student Management System");
        do {

                    System.out.println("Menu:");
                    System.out.println("1.Add Student");
                    System.out.println("2.Delete Student");
                    System.out.println("3.Update Student");
                    System.out.println("4.Search Student");
                    System.out.println("5.View Students");
                    System.out.print("Enter your choice: ");

                    choice = scanner.nextInt();

                    switch (choice) {
                        case 1:
                         std.addstudent();
                            break;
                        case 2:
                           std.Deletestud();
                            break;
                        case 3:
                            std.Update();
                            break;
                        case 4 :
                            std.Search();
                            break;
                        case 5 :
                            std.viewStudents();
                            break;
                        default:
                            System.out.println("Invalid choice. Please try again.");
                    }
                } while (choice != 6);

                scanner.close();
            }
        }

